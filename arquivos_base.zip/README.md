# genetic_stock_predictions
Projeto de aula sobre análise de previsão de ações, usando algoritmos genéticos.
